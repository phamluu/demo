<?php
/**
 * WP Travel Emgine Cart.
 *
 * @deprecated 5.7.4 Use WPTravelEngine\Cart\Cart instead.
 * @package WP Travel Engine
 */

// Exit if accessed directly.
use WPTravelEngine\Core\Cart\Cart;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * WP Travel Engine Cart Shortcode Class.
 *
 * @deprecated 5.7.4 Use WPTravelEngine\Cart\Cart instead.
 */
class WTE_Cart extends Cart {
}
