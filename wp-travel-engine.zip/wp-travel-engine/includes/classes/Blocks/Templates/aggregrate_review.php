<!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column {"style":{"border":{"right":{"color":"#0000001a","width":"1px"},"top":[],"bottom":[],"left":[]}},"layout":{"type":"default"}} -->
<div class="wp-block-column" style="border-right-color:#0000001a;border-right-width:1px"><!-- wp:wptravelenginetripblocks/trip-ratings /-->

<!-- wp:wptravelenginetripblocks/star-ratings {"margin":{"top":"","right":"","bottom":"8px","left":""}} /-->

<!-- wp:wptravelenginetripblocks/reviews-count /--></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:wptravelenginetripblocks/stars-bar-graph /--></div>
<!-- /wp:column --></div>
<!-- /wp:columns -->