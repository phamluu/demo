<?php
/**
 * Abstract Deprecated class.
 *
 * @package WPTravelEngine
 *
 * @since 6.0.0
 */

namespace WPTravelEngine\Abstracts;

/**
 * Deprecated class.
 *
 * @since 6.0.0
 */

/**
 * Deprecated class.
 *
 * @since 1.0.0
 */
abstract class Deprecated {
	abstract public function deprecated();
}
