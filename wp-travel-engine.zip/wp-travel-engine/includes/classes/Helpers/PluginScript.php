<?php
/**
 * Plugin Asset Helper.
 *
 * @package WPTravelEngine
 * @since 6.0.0
 */

namespace WPTravelEngine\Helpers;

/**
 * Asset Helper class.
 *
 * @since 6.0.0
 */
class PluginScript extends Asset {

}
