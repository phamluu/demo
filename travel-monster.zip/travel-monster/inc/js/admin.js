jQuery(document).ready(function ($) {

    //Sortable for social links
    $('.user-social-sortable-icons').sortable({
        cursor: "move"
    });

});